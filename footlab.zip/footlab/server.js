// ============================================================
//  FOOTLAB — Backend com dados reais em tempo real
//  Notícias: RSS atualizado a cada 5 minutos
//  Jogos:    TheSportsDB API (gratuita, sem chave)
//  Cache:    em memória, nunca stale > 5 min
// ============================================================

const express  = require('express');
const cors     = require('cors');
const cron     = require('node-cron');
const fs       = require('fs');
const path     = require('path');
const axios    = require('axios');
const Parser   = require('rss-parser');

const app    = express();
const PORT   = process.env.PORT || 3000;
const parser = new Parser({ timeout: 8000, headers: { 'User-Agent': 'FootLab/1.0' } });

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// ── Pasta de dados ──────────────────────────────────────────
const DATA_DIR  = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'posts.json');
if (!fs.existsSync(DATA_DIR))  fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]');

// ── Cache em memória ─────────────────────────────────────────
let postsCache   = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
let matchesCache = [];
let matchesLastFetch = 0;
const MATCHES_TTL = 5 * 60 * 1000; // 5 minutos

// ── Fontes RSS reais ─────────────────────────────────────────
const RSS_SOURCES = [
  { url: 'https://feeds.bbci.co.uk/sport/football/rss.xml',     name: 'BBC Sport'   },
  { url: 'https://www.skysports.com/rss/12040',                  name: 'Sky Sports'  },
  { url: 'https://www.espn.com/espn/rss/soccer/news',           name: 'ESPN'        },
  { url: 'https://www.goal.com/feeds/en/news',                   name: 'Goal'        },
  { url: 'https://www.record.pt/feed/futebol',                   name: 'Record PT'   },
  { url: 'https://www.maisfutebol.iol.pt/rss',                   name: 'Maisfutebol' },
];

// Imagens de fallback (Unsplash – futebol)
const FALLBACK_IMGS = [
  'https://images.unsplash.com/photo-1459865264687-595d652de67e?w=800&q=80',
  'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=800&q=80',
  'https://images.unsplash.com/photo-1543326727-cf6c39e8f84c?w=800&q=80',
  'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&q=80',
  'https://images.unsplash.com/photo-1553778263-73a83bab9b0c?w=800&q=80',
];

// ── Extrair imagem do feed RSS ────────────────────────────────
function extractImage(item) {
  if (item.enclosure?.url) return item.enclosure.url;
  if (item['media:thumbnail']?.$?.url) return item['media:thumbnail'].$.url;
  if (item['media:content']?.$?.url)   return item['media:content'].$.url;
  // tenta extrair de content HTML
  const match = (item.content || item['content:encoded'] || '').match(/<img[^>]+src="([^"]+)"/);
  if (match) return match[1];
  return FALLBACK_IMGS[Math.floor(Math.random() * FALLBACK_IMGS.length)];
}

// ── Detectar categoria ────────────────────────────────────────
function detectCategory(title = '') {
  const t = title.toLowerCase();
  if (t.includes('transfer') || t.includes('signing') || t.includes('contrat')) return 'Transferências';
  if (t.includes('injur') || t.includes('lesão') || t.includes('lesion'))        return 'Lesões';
  if (t.includes('champions') || t.includes('ucl'))                               return 'Champions League';
  if (t.includes('europa league') || t.includes('uel'))                           return 'Europa League';
  if (t.includes('girabola') || t.includes('angola') || t.includes('palancas'))   return 'Girabola';
  if (t.includes('premier') || t.includes('epl') || t.includes('arsenal') || t.includes('chelsea') || t.includes('united')) return 'Premier League';
  if (t.includes('la liga') || t.includes('laliga') || t.includes('real madrid') || t.includes('barcelona') || t.includes('atletico')) return 'La Liga';
  if (t.includes('serie a') || t.includes('juve') || t.includes('inter') || t.includes('milan')) return 'Serie A';
  if (t.includes('bundesliga') || t.includes('bayern') || t.includes('dortmund')) return 'Bundesliga';
  if (t.includes('world cup') || t.includes('mundial') || t.includes('fifa'))     return 'Mundial';
  if (t.includes('africa') || t.includes('can ') || t.includes('chan'))           return 'África';
  return 'Destaques';
}

// ── Buscar notícias RSS ───────────────────────────────────────
async function fetchRSS() {
  let all = [];
  for (const src of RSS_SOURCES) {
    try {
      const feed = await parser.parseURL(src.url);
      const items = feed.items.slice(0, 8).map(item => ({
        id:          item.guid || item.link,
        title:       item.title?.trim() || '',
        content:     item.contentSnippet?.trim() || item.summary?.trim() || item.title?.trim() || '',
        originalLink:item.link,
        image:       extractImage(item),
        source:      src.name,
        pubDate:     item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
        publishedAt: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
        category:    detectCategory(item.title),
        author:      item.creator || item.author || src.name,
      }));
      all.push(...items);
    } catch (err) {
      console.warn(`⚠️  RSS falhou [${src.name}]:`, err.message);
    }
  }
  // Ordenar por data mais recente
  all.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));
  // Remover duplicados por título
  const seen = new Set();
  return all.filter(a => {
    if (!a.title || seen.has(a.title)) return false;
    seen.add(a.title);
    return true;
  });
}

// ── Actualizar posts ──────────────────────────────────────────
async function refreshNews() {
  console.log('🔄 FootLab: A actualizar notícias RSS...');
  try {
    const fresh = await fetchRSS();
    if (!fresh.length) { console.warn('⚠️  Nenhuma notícia obtida'); return; }

    // Manter posts antigos que ainda não existam nos frescos
    const freshIds = new Set(fresh.map(a => a.id));
    const kept = postsCache.filter(p => !freshIds.has(p.id));

    // Fusão: frescos primeiro + antigos sem repetição, máx 100
    postsCache = [...fresh, ...kept].slice(0, 100);
    fs.writeFileSync(DATA_FILE, JSON.stringify(postsCache, null, 2));
    console.log(`✅ ${fresh.length} notícias obtidas | Cache: ${postsCache.length} artigos`);
  } catch (err) {
    console.error('❌ Erro ao actualizar notícias:', err.message);
  }
}

// ── Buscar jogos reais (TheSportsDB – gratuito, sem chave) ────
async function fetchMatches() {
  const now = Date.now();
  if (matchesCache.length && now - matchesLastFetch < MATCHES_TTL) {
    return matchesCache; // ainda válido
  }

  console.log('🔄 FootLab: A buscar jogos em tempo real...');
  const leagues = [
    { id: '4328', name: 'Premier League'   },
    { id: '4335', name: 'La Liga'          },
    { id: '4331', name: 'Bundesliga'       },
    { id: '4332', name: 'Serie A'          },
    { id: '4334', name: 'Ligue 1'          },
    { id: '4480', name: 'Champions League' },
  ];

  let allMatches = [];
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

  for (const league of leagues) {
    try {
      const url = `https://www.thesportsdb.com/api/v1/json/3/eventsday.php?d=${today}&l=${league.id}`;
      const { data } = await axios.get(url, { timeout: 6000 });
      if (data?.events) {
        const mapped = data.events.slice(0, 3).map(e => ({
          id:          e.idEvent,
          competition: league.name,
          home:        e.strHomeTeam,
          away:        e.strAwayTeam,
          time:        e.strTime ? e.strTime.substring(0,5) : '--:--',
          scoreHome:   e.intHomeScore,
          scoreAway:   e.intAwayScore,
          status:      e.strStatus || 'NS',   // NS=Not Started, FT=Full Time, etc
          venue:       e.strVenue || '',
          date:        e.dateEvent,
        }));
        allMatches.push(...mapped);
      }
    } catch (err) {
      console.warn(`⚠️  Jogos falhou [${league.name}]:`, err.message);
    }
  }

  // Se não houver jogos hoje, buscar os próximos 7 dias para cada liga
  if (!allMatches.length) {
    console.log('ℹ️  Sem jogos hoje. A buscar próximos eventos...');
    for (const league of leagues.slice(0, 3)) {
      try {
        const url = `https://www.thesportsdb.com/api/v1/json/3/eventsnextleague.php?id=${league.id}`;
        const { data } = await axios.get(url, { timeout: 6000 });
        if (data?.events) {
          const mapped = data.events.slice(0, 2).map(e => ({
            id:          e.idEvent,
            competition: league.name,
            home:        e.strHomeTeam,
            away:        e.strAwayTeam,
            time:        e.strTime ? e.strTime.substring(0,5) : '--:--',
            scoreHome:   e.intHomeScore,
            scoreAway:   e.intAwayScore,
            status:      'Em breve',
            venue:       e.strVenue || '',
            date:        e.dateEvent,
          }));
          allMatches.push(...mapped);
        }
      } catch (err) {
        console.warn(`⚠️  Próximos eventos falhou [${league.name}]:`, err.message);
      }
    }
  }

  matchesCache = allMatches;
  matchesLastFetch = now;
  console.log(`✅ ${allMatches.length} jogos obtidos`);
  return matchesCache;
}

// ════════════════════════════════════════════════════════════
//  API ENDPOINTS
// ════════════════════════════════════════════════════════════

// Notícias (cache em memória, sempre frescas)
app.get('/api/news', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 12, 50);
  const cat   = req.query.category;
  let posts   = postsCache;
  if (cat) posts = posts.filter(p => p.category === cat);
  res.json(posts.slice(0, limit));
});

// Últimas 5 para o ticker
app.get('/api/latest', (req, res) => {
  res.json(postsCache.slice(0, 5));
});

// Jogos reais
app.get('/api/matches', async (req, res) => {
  try {
    const matches = await fetchMatches();
    res.json(matches);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar jogos', detail: err.message });
  }
});

// Categorias disponíveis
app.get('/api/categories', (req, res) => {
  const cats = [...new Set(postsCache.map(p => p.category).filter(Boolean))];
  res.json(cats);
});

// Status do servidor
app.get('/api/status', (req, res) => {
  res.json({
    ok:          true,
    posts:       postsCache.length,
    lastUpdated: postsCache[0]?.publishedAt || null,
    matchesCached: matchesCache.length,
    uptime:      Math.floor(process.uptime()) + 's',
  });
});

// Forçar actualização manual (ex: painel admin)
app.post('/api/refresh', async (req, res) => {
  await refreshNews();
  matchesLastFetch = 0; // invalida cache de jogos
  res.json({ ok: true, posts: postsCache.length });
});

// ════════════════════════════════════════════════════════════
//  AGENDADOR — actualiza notícias a cada 5 minutos
// ════════════════════════════════════════════════════════════
cron.schedule('*/5 * * * *', () => {
  refreshNews();
});

// Primeira execução imediata ao arrancar
setTimeout(refreshNews, 2000);

// ════════════════════════════════════════════════════════════
//  ARRANQUE
// ════════════════════════════════════════════════════════════
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════╗
║   ⚽  FOOTLAB — Dados Reais em Tempo Real    ║
║   🌐  http://localhost:${PORT}                 ║
║                                              ║
║   ✅  Notícias RSS  → atualiza cada 5 min   ║
║   ✅  Jogos reais   → TheSportsDB API        ║
║   ✅  Cache memória → sem leituras de disco  ║
╚══════════════════════════════════════════════╝
  `);
});
