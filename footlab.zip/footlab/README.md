# 🧠 FootLab IA — Guia de Instalação

## Estrutura do Projeto
```
footlab/
├── package.json       ← Dependências Node.js
├── server.js          ← Backend + IA autónoma
├── data/
│   └── posts.json     ← Artigos publicados (criado automaticamente)
└── public/
    └── index.html     ← Frontend do site
```

---

## ▶️ Opção 1 — Servidor Node.js (Recomendado)

### Pré-requisitos
- Node.js instalado (https://nodejs.org)

### Passos
```bash
# 1. Entrar na pasta
cd footlab

# 2. Instalar dependências
npm install

# 3. Iniciar o servidor
npm start
```

Abrir no browser: **http://localhost:3000**

A IA publica automaticamente às **08:00, 14:00 e 20:00** todos os dias.

---

## 🌐 Opção 2 — WordPress (Iframe Embed)

Se quiseres publicar o FootLab dentro do WordPress:

### Passo 1 — Hospedar o backend
Usa um serviço como **Railway**, **Render** ou **Heroku** para hospedar o `server.js`.
Depois substitui no `index.html` a linha:
```js
const API_URL = 'http://localhost:3000';
```
pelo URL do teu servidor online, exemplo:
```js
const API_URL = 'https://footlab-ia.railway.app';
```

### Passo 2 — Publicar o HTML no WordPress
1. Cria uma nova **Página** no WordPress
2. Adiciona um bloco **HTML Personalizado**
3. Cola o conteúdo completo do `public/index.html`
4. Publica a página

### Passo 3 — Alternativa com plugin
Instala o plugin **"WPCode"** ou **"Insert Headers and Footers"** e cola o HTML como shortcode.

---

## 🤖 Como funciona a IA

- Busca notícias em 6 fontes RSS (BBC, Sky Sports, ESPN, Goal, Marca, Record)
- Reescreve cada notícia com personalidade FootLab
- Publica automaticamente 3-4 artigos por dia
- Deteta categorias automaticamente (Champions, Premier League, Girabola, etc.)
- Gera palpites de jogos com probabilidades

---

## ⚙️ Personalização

Para mudar as fontes RSS, edita o array `NEWS_SOURCES` no `server.js`.
Para mudar o horário de publicação, edita o cron:
```js
cron.schedule('0 8,14,20 * * *', ...)
// Formato: minuto hora * * *
```

---

© 2025 FootLab — Laboratório do Futebol com IA Autónoma
